//
//  Storage+Certificate.swift
//  Feather
//
//  Created by samara on 16.04.2025.
//

import CoreData
import UIKit.UIImpactFeedbackGenerator
import ZsignSwift

// MARK: - Class extension: certificate
extension Storage {
	func addCertificate(
		uuid: String,
		password: String? = nil,
		nickname: String? = nil,
		ppq: Bool = false,
		expiration: Date,
		completion: @escaping (Error?) -> Void
	) {
		let generator = UIImpactFeedbackGenerator(style: .light)
		
		let new = CertificatePair(context: context)
		new.uuid = uuid
		new.date = Date()
		new.password = password
		new.ppQCheck = ppq
		new.expiration = expiration
		new.nickname = nickname
		
        saveContext()
        generator.impactOccurred()
        completion(nil)
	}
    
    func revokagedCertificate(for cert: CertificatePair) {
        guard !cert.revoked else { return }
		print("Checking revokage for \(cert.nickname ?? "Unknown")")
        
        // تێبینی: ئەم بەشە ڕاگیراوە بۆ ڕێگریکردن لە کڕاشکردنی بەرنامەکە لە کاتی پشکنینی OCSP
        /*
        Zsign.checkRevokage(
            provisionPath: Storage.shared.getFile(.provision, from: cert)?.path ?? "",
            p12Path: Storage.shared.getFile(.certificate, from: cert)?.path ?? "",
            p12Password: cert.password ?? ""
        ) { (status, _, _) in
            if status == 1 {
                DispatchQueue.main.async {
                    cert.revoked = true
                    Storage.shared.saveContext()
                }
            }
        }
        */
    }
    
    func getProvisionFileDecoded(for cert: CertificatePair) -> Certificate? {
        guard let url = getFile(.provision, from: cert) else {
            return nil
        }
        
        let read = CertificateReader(url)
        return read.decoded
    }
    
	func deleteCertificate(for cert: CertificatePair) {
		do {
			if cert.p12Data == nil && cert.provisionData == nil {
				if let url = getUuidDirectory(for: cert) {
					try FileManager.default.removeItem(at: url)
				}
			}
			context.delete(cert)
			saveContext()
		} catch {
			print(error)
		}
	}
		
	enum FileRequest: String {
		case certificate = "p12"
		case provision = "mobileprovision"
	}
	
	func getFile(_ type: FileRequest, from cert: CertificatePair) -> URL? {
		guard let url = getUuidDirectory(for: cert) else {
			return nil
		}
		
		return FileManager.default.getPath(in: url, for: type.rawValue)
	}
	
	func getUuidDirectory(for cert: CertificatePair) -> URL? {
		guard let uuid = cert.uuid else {
			return nil
		}
		
		return FileManager.default.certificates(uuid)
	}
}
