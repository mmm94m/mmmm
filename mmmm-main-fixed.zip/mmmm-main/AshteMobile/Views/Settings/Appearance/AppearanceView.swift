//
//  AppearanceView.swift
//  Feather
//
//  Created by samara on 7.05.2025.
//

import SwiftUI
import NimbleViews

struct AppearanceView: View {
    @AppStorage("AshteMobile.userInterfaceStyle") private var _userIntefacerStyle: Int = UIUserInterfaceStyle.unspecified.rawValue
    
	@AppStorage("AshteMobile.libraryCellAppearance") private var _libraryCellAppearance: Int = 0
	
	private let _libraryCellAppearanceMethods: [String] = [
		.localized("Standard"),
		.localized("Pill")
	]
	
	@AppStorage("AshteMobile.storeCellAppearance") private var _storeCellAppearance: Int = 1
	
	private let _storeCellAppearanceMethods: [String] = [
		.localized("Standard"),
		.localized("Big Description")
	]
	
	@AppStorage("AshteMobile.accentColor") private var _selectedAccentColor: Int = 0
	@AppStorage("AshteMobile.customAccentColor") private var _customAccentColor: String = "#3482c9"
	@StateObject private var accentColorManager = AccentColorManager.shared
	@State private var _showColorPicker = false
    
	private let _accentColors: [(name: String, color: Color)] = [
		(.localized("Default"), Color(red: 0x34/255, green: 0x82/255, blue: 0xC9/255)),
		(.localized("Cherry"), Color(red: 0xFF/255, green: 0x8B/255, blue: 0x92/255)),
		(.localized("Red"), .red),
		(.localized("Orange"), .orange),
		(.localized("Yellow"), .yellow),
		(.localized("Green"), .green),
		(.localized("Blue"), .blue),
		(.localized("Purple"), .purple),
		(.localized("Pink"), .pink),
		(.localized("Indigo"), .indigo),
		(.localized("Mint"), .mint),
		(.localized("Cyan"), .cyan),
		(.localized("Teal"), .teal),
		(.localized("Custom"), Color.clear)
	]
	
	private var currentAccentColor: Color {
		accentColorManager.currentAccentColor
	}

    var body: some View {
        NBList(.localized("Appearance")) {
            
            Section {
                Picker(.localized("Appearance"), selection: $_userIntefacerStyle) {
                    ForEach(UIUserInterfaceStyle.allCases.sorted(by: { $0.rawValue < $1.rawValue }), id: \.rawValue) { style in
                        Text(style.label).tag(style.rawValue)
                    }
                }
                .pickerStyle(.segmented)
            }
			
			NBSection(.localized("Sources")) {
                _storePreview()
				Picker(.localized("Store Cell Appearance"), selection: $_storeCellAppearance) {
					ForEach(_storeCellAppearanceMethods.indices, id: \.self) { index in
						Text(_storeCellAppearanceMethods[index]).tag(index)
					}
				}
				.pickerStyle(.inline)
                .labelsHidden()
			}

			NBSection(.localized("Accent Color")) {
				_accentColorPreview()
				Picker(.localized("Accent Color"), selection: $_selectedAccentColor) {
					ForEach(_accentColors.indices, id: \.self) { index in
						HStack {
							if index == _accentColors.count - 1 {
								// Rainbow gradient for custom
								Circle()
									.fill(
										LinearGradient(
											colors: [.red, .orange, .yellow, .green, .blue, .purple],
											startPoint: .topLeading,
											endPoint: .bottomTrailing
										)
									)
									.frame(width: 20, height: 20)
							} else {
								Circle()
									.fill(_accentColors[index].color)
									.frame(width: 20, height: 20)
							}
							Text(_accentColors[index].name)
						}
						.tag(index)
					}
				}
				.pickerStyle(.inline)
				.labelsHidden()
				.onChange(of: _selectedAccentColor) { newValue in
					if newValue == _accentColors.count - 1 {
						_showColorPicker = true
					}
				}
			}
		}
        .onChange(of: _userIntefacerStyle) { value in
            if let style = UIUserInterfaceStyle(rawValue: value) {
                UIApplication.topViewController()?.view.window?.overrideUserInterfaceStyle = style
            }
        }
		.onChange(of: _selectedAccentColor) { _ in
			accentColorManager.updateGlobalTintColor()
		}
		.sheet(isPresented: $_showColorPicker) {
			ColorPickerView(
				selectedColor: $_customAccentColor,
				onColorSelected: { color in
					_customAccentColor = color
					accentColorManager.updateGlobalTintColor()
				}
			)
		}
		.padding(.bottom, 80) // Extra space for bottom bar
    }
	
	@ViewBuilder
	private func _libraryPreview() -> some View {
		HStack(spacing: 9) {
			Image(uiImage: UIImage.appIcon)
				.appIconStyle(size: 57)
			
			NBTitleWithSubtitleView(
				title: Bundle.main.name,
				subtitle: "\(Bundle.main.version) • \(Bundle.main.bundleIdentifier ?? "")",
				linelimit: 0
			)
			
			FRExpirationPillView(
				title: .localized("Install"),
				showOverlay: _libraryCellAppearance == 0,
				expiration: Date.now.expirationInfo()
			).animation(.spring, value: _libraryCellAppearance)
		}
	}
    
    @ViewBuilder
    private func _storePreview() -> some View {
        VStack {
            HStack(spacing: 9) {
                Image(uiImage: UIImage.appIcon)
                    .appIconStyle(size: 57)
                
                NBTitleWithSubtitleView(
                    title: Bundle.main.name,
                    subtitle: "\(Bundle.main.version) • " + .localized("An awesome application"),
                    linelimit: 0
                )
            }
            
            if _storeCellAppearance != 0 {
                Text(.localized("An awesome application"))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .lineLimit(18)
                    .padding(.top, 2)
            }
        }
        .animation(.spring, value: _storeCellAppearance)
    }
	
	@ViewBuilder
	private func _accentColorPreview() -> some View {
		HStack(spacing: 9) {
			Circle()
				.fill(currentAccentColor)
				.frame(width: 57, height: 57)
			
			NBTitleWithSubtitleView(
				title: .localized("Accent Color"),
				subtitle: .localized("This is the current accent color"),
				linelimit: 0
			)
		}
	}
}
